# Netduma Address Book (Author: John Lynch, Date: 2019-10-01)

The application is not finished but time has run out.

A more extensive README will follow shortly.
