// Netduma Address Book
// Author: John Lynch
// Date: 2019-10-01

const contacts_file = `contacts_file.json` ;    // temporarily hard-coded - change to let user choose the address book
let contacts = [];
const fields = [`firstname`, `othernames`, `email`, `phone`, `street`, `town`, `country`];
const friendly_fields = [`First Name`, `Other Names`, `Email`, `Phone`, `Street`, `Town`, `Country`];
const field_codes = fields.map(field => field.slice(0, 1));
let buttons_added = false;

const btn_add = document.getElementById(`btn-add`);
const btn_find = document.getElementById(`btn-find`);
const btn_save = document.getElementById(`btn-save`);
const btn_help = document.getElementById(`btn-help`);

btn_add.addEventListener(`click`, addContact);
btn_find.addEventListener(`click`, findContact);
btn_save.addEventListener(`click`, saveContacts);
btn_help.addEventListener(`click`, showHelp);

function saveContacts() {
    console.log(`Saving contacts...`);
    // Save contacts to local storage (and save to address book?)
}

function showHelp() {
    console.log(`Displaying usage info to user...`)
    // Display Usage Info to user
}

async function load_contacts(jsonfile) {
    // Get JSON data from the given file and return it formatted as table markup
    const res = await fetch(jsonfile);
    const data = await res.json();
    return data;
}

function addContact() {
    console.log(`Add contact...`);
    let contact = {};
    // To implement: Display a form for user to enter contact details
    // Set fields of contact according to user input
    contacts.push(contact);
    console.log(`Contact details for ${contact.firstname} added to Address Book!`);
}

function removeContact(index) {
    console.log(`Contact removed!`);
    contacts.splice(index, 1);
    return contacts;
}

function showContacts(contacts) {
    const markup = jsonToTable(contacts);
    const table = document.getElementById(`info-table`);
    
    table.getElementsByTagName(`thead`)[0].innerHTML = markup[0];
    table.getElementsByTagName(`tbody`)[0].innerHTML = markup[1];

    let show_buttons = table.querySelectorAll(`[id^="btn-show"]`);
    let delete_buttons = table.querySelectorAll(`[id^="btn-delete"]`);

    // Set up event listeners for all Delete buttons
    delete_buttons.forEach(button => {
        button.addEventListener(`click`, ev => {
            const idstr = ev.target.id;
            console.log(`Button id ${idstr} clicked`);
            const id = parseInt(idstr.slice(idstr.lastIndexOf(`-`) + 1));
            console.log(`id = ${id}\n`);
            console.log(`contacts['id'] = ${contacts['id']}\n`);
            contact = contacts.find(item => item[`id`] == id);
            // Removing wrong contact - needs debugging!
            showContacts(removeContact(contact));
        });
    });

    // Set up event listeners for all Show buttons
    show_buttons.forEach(button => {
        button.addEventListener(`click`, ev => {
            console.log(`Button id ${ev.target.id} clicked`);
            // Show the contact details to the user
        });
    });

}

function findContact(field_index, value) {
    let soughtIsFound = false;
    let current_index = 0;
    while (!soughtIsFound && current_index < contacts.length) {
        let remaining_contacts = contacts.slice(current_index);
        let contact = remaining_contacts.find(item => item[fields[field_index]].toLowerCase() == value);
        // Show contact to user, update current_index, ask if correct contact found, and if not, loop
    }
}

function jsonToTable(jsondata) {
    let id = 0;
    let tb_markup = ``;
    // Get list of fields, based on first entry
    let fields = Object.keys(jsondata[0]);
    if (!buttons_added) {
        fields = fields.concat([`show`, `delete`]);
    }
    // Generate markup for table head
    const th_markup = `<tr>\n${fields.map(field => `    <th>${field}</th>`).join(`\n`)}\n</tr>`;
    // Generate markup for table body
    jsondata.forEach(item => {
        if (!buttons_added) {
            item[`show`] = `<button class="btn" id="btn-show-${id}">Show</button>`;
            item[`delete`] = `<button class="btn" id="btn-delete-${id++}">Delete</button>`;
        }
        tb_markup += `<tr>\n${fields.map(field => `    <td>${item[field]}</td>`).join(`\n`)}\n</tr>\n`;
    });
    buttons_added = true;
    return [th_markup, tb_markup];
}

// Main entry point
async function start() {
    contacts = await load_contacts(contacts_file);
    let id = 0;
    contacts.forEach(contact => {
        contact[`id`] = id++;
    })
    showContacts(contacts);
}

// ===========================================================================================

start();
