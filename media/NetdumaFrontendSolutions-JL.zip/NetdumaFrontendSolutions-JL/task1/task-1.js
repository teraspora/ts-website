// Netduma Frontend Technical Test - Task 1
// John Lynch
// 29-09-2019

const file = `task-1-info.json`;

async function load_json(jsonfile) {
    // Get JSON data from the given file and return it formatted as table markup
    const res = await fetch(jsonfile);
    const data = await res.json();
    return jsonToTable(data);
}

function update_table(markup) {
    // Populate table head and body with the markup string passed in
    const table = document.getElementById(`info-table`);
    table.getElementsByTagName(`thead`)[0].innerHTML = markup[0];
    table.getElementsByTagName(`tbody`)[0].innerHTML = markup[1];
}


function jsonToTable(jsondata) {
    let tb_markup = ``;
    // Get list of fields, based on first entry
    const fields = Object.keys(jsondata[0]);
    // Generate markup for table head
    const th_markup = `<tr>\n${fields.map(field => `    <th>${field}</th>`).join(`\n`)}\n</tr>`;
    // Generate markup for table body
    jsondata.forEach(item => {
        tb_markup += `<tr>\n${fields.map(field => `    <td>${item[field]}</td>`).join(`\n`)}\n</tr>\n`;
    });
    return [th_markup, tb_markup];
}

async function start() {
    const markup = await load_json(file);
    update_table(markup);
}
// ================================================================================================

start()
