// Netduma Frontend Technical Test - Task 4
// John Lynch
// 29-09-2019


// Function that when given a string, will return 
// true if at least 1 permutation of the string is a palindrome.
function hasPalindromicPerm(s) {
    s = s.replace(/\s/g, '');
    const chars = [...new Set(s)];
    const counts = chars.map(char => (s.match(new RegExp(char, 'g')) || []).length)
    const odd_counts = counts.filter(count => count % 2 == 1).length;
    return odd_counts <= 1;
}