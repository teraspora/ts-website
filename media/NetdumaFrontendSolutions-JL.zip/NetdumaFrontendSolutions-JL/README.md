# NetDuma Frontend Technical Test - John Lynch

## Background

When I attempted this test on Friday it was the day after I had been travelling for around fifteen hours, by cars, trains, buses and plane, back home from holiday in the mountains of central Italy.   I was therefore somewhat exhausted.   Also, I had hardly been coding for a fortnight.

I should, therefore, have asked Thomas Allen to schedule the test for Monday, but he seemed very keen that I do it asap, so I concurred.   This was a mistake, as my brain was not ready for it at all.   After some time I realised my thinking was not at all sharp enough to do a good job, so, as you know, I gave up.

Having now recovered, I decided to do the tasks untimed.

## Task 1

### Issues

- CORS policy error due to reading a local file
    Solution:   Used [Live Server](https://www.npmjs.com/package/live-server)

- Had to read the docs about `fetch()` and `async`/`await` as this was a weak area in my knowledge.

- To generate the markup for the HTML Table content I used a template literal within an anonymous function within a template literal.   I wasn't sure whether this would work, but a trial in the Dev Tools console showed it does.

- Although the data is displayed as specified, there is always the following error in the console:
    `Unchecked runtime.lastError: The message port closed before a response was received.`
    Currently I have not determined the cause of this or how to obviate it.

- I tried various hacks from various websites to get the table head to be sticky, but currently have found no satisfactory solution.

### Future Improvements

- Solve the unsolved issues documented above
- Style the table better, implementing responsive design
- Allow the user to select the file of JSON data
- Decide how to handle data items that don't fit in their columns:
     `overflow-x: scroll` is not really satisfactory for table rows...

## Task 2

### Issues

- After playing with this code a bit till I understood it, I decided to rewrite much of the `gen()` and `draw()` functions.

- As originally implemented, the code generates multiple radii at intervals, and the screen fills with dots and circles, so it's impossible to see which dots relate to which circle; whereas the specification says

>The code should generate a random amount of points, a centre point, and a radius.

with radius in the singular.   I decided to implement functionality as specified, with a single radius, getting rid of the timeout after drawing, but allowing the user to regenerate by clicking in the canvas.

- I found it simpler when generating the array of dots to calculate each dot's distance from the centre and store it as a property of the dot, so it then becomes easy to map this to a colour when drawing.

- I reduced the dot size from 3 to 2, which improves the look.

- I added a thin border to the canvas.

## Task 3

1. Solve any problems you find related with the calculation of the office's efficiency.
    - Replace 
        `sum *= office.workers[i].efficiency;` with 
        `sum += office.workers[i].efficiency;`.
    - Replace 
        `sum = Math.round(1000 * Math.pow(sum, 1 / office.workers.length)) / 1000;` with 
        `const mean_efficiency = sum / numWorkers;` etc..

3. Create a better efficiency to colour conversion for each worker. The higher their efficiency, the closer to green their colour should be. The lower, it should be closer to red.
    - The range of values of worker efficiency is not stated, but from examining some in the console I guess it's a percentage, i.e. from 0 to 100.
    - Let's change 
        `'rgb(' + parseInt(efficiency/100 * 255) + ', ' + parseInt(255 - (efficiency)) + ', 0)'`
        to
        `rgb(${255 - neff}, ${neff}, 0)`
        where `neff = Math.round(efficiency * 2.55)`.
        This gives better red/green representation of efficiency as specified.

2. Design and create a better way to display the information than just plain text.
and
4. Make as many other graphical improvements as you wish.
    - There are many possibilities for design changes and "graphical improvements".
        - There is insufficient contrast ratio between light green text and background; changing the background to black fixed this; so needed also to change the column-header and efficiency text to a light colour.
        - Increased font size to `0.9vw`.
5. Provide a brief explanation of how to use the browser's console debugger.
    - In the "Sources" tab by opening Javascript files and clicking on the line numbers I can toggle breakpoints.   In the right-hand panel I can check the values of variables in scope, and can step through code statement by statement or by skipping over a function etc.
    - In the "Console" tab I can check the values of expressions, try out new code etc.

## Task 4

Given a string `s`, at least 1 permutation of `s` being a
palindrome is equivalent to:

- if `s.length` is even: there are even numbers of each letter;
- if `s.length` is odd: there are even numbers of each letter except one;

So,

1. Remove spaces from string. 
2. Make a set of the distinct characters.
3. Count the occurrences of each of these.
4. Filter out the even totals.
5. If there is more than one odd count, return false, else return true.

`function hasPalindromicPerm()` can be found in `task-4.js`.

## Conclusion

I have not timed myself doing this, but have definitely taken more than 4 hours.
