/**
 * The code should generate a random amount of points, a centre point, and a radius.
 * When they are drawn, the dots should be green if they are within the radius from the centre.
 * The further away from the radius they are when outside, the darker the red they should be.
 * 
 * Fix any problems you can identify in the code, and add improve the code as much as you wish.
 */

var dots = []
var centre = {}
var radius = 0;
var c = document.getElementById("canvas")
var ctx = c.getContext("2d")
var distances = []

function draw() {

  ctx.beginPath()
  ctx.strokeStyle = "#0000FF"
  ctx.arc(centre.x,centre.y,radius,0,Math.PI * 2);
  ctx.stroke();


  for(i = 0; i < dots_length; i += 1){
    dot = dots[i]
    dot_x = centre.x - dot.x
    if (dot_x < 0){
      dot_x = dot_x * -1
    }
    dot_y = centre.y - dot.y
    if (dot_y < 0){
      dot_y = dot_x * -1
    }

    distance = {}
    if(dot_x < radius & dot_y < radius){
      distance.in = true
    }else{
      distance.in = false
    }
    distance.dis = (dot_x + dot_y) / 2
    distances.push(distance)
  }

  for(i -= 1; i > 0; i -= 1) {
    distance = distances[i]
    dot = dots[i]
    if (distance.in){
      ctx.fillStyle = "#00FF00"
    }else{
      ctx.fillStyle = 'rgb(' + distance.dis + ',' + 0 + ',' + 0 + ')'
    }
    ctx.fillRect(dot.x,dot.y,3,3)
  }

  setTimeout(gen.bind(this), 5000)
}


function randomInteger(min, max) {
  return Math.floor(Math.random() * (max - min + 1) ) + min;
}

function gen() {
  dots_length = randomInteger(10,50);
  dots_length_tmp = dots_length
  dots = []
  while(dots_length_tmp >= 0){
    x = randomInteger(0,c.width)
    y = randomInteger(0,c.height)
    newpos = {}
    newpos.x = x
    newpos.y = y
    dots.push(newpos)
    dots_length_tmp = dots_length_tmp - 1
  }

  x = randomInteger(0,c.width)
  y = randomInteger(0,c.height)
  newpos = {}
  newpos.x = x
  newpos.y = y
  centre = newpos

  radius = randomInteger(0,50)

  draw()
}

gen()