// Netduma Frontend Technical Test - Task 2
// John Lynch
// 29-09-2019

/**
 * The code should generate a random amount of points, a centre point, and a radius.
 * When they are drawn, the dots should be green if they are within the radius from the centre.
 * The further away from the radius they are when outside, the darker the red they should be.
 * 
 * Fix any problems you can identify in the code, and add improve the code as much as you wish.
 */

let dots = [];
let centre = {};
let radius = 0;
const c = document.getElementById("canvas");
const ctx = c.getContext("2d");
// Listen for user clicking in canvas, and re-generate.
c.addEventListener(`click`, _ => {
  gen();
});

function draw() {
  // Draw a circle of radius and centre set in gen().
  ctx.beginPath();
  ctx.strokeStyle = "#0000FF";
  ctx.arc(centre.x,centre.y, radius, 0, Math.PI * 2);
  ctx.stroke();

  // Paint the dots generated in gen().
  for (let dot of dots) {
    // Make dots green if inside radius, red outside and darker red if further from centre.
    // Note: if 255 - dot.dist is negative it's effectively clamped to zero by the browser.
    ctx.fillStyle = dot.dist < radius ? "#00FF00" : 'rgb(' + (255 - dot.dist) + ',' + 0 + ',' + 0 + ')';
    ctx.fillRect(dot.x, dot.y, 2, 2);
  }
}

function gen() {
    dots = [];
    const [w, h] = [c.width, c.height];
    // Clear the canvas.
    ctx.clearRect(0, 0, w, h);
    // Set circle parameters.
    centre = {x: randomInteger(0, w), y: randomInteger(0, h)};
    radius = randomInteger(0,50);

    let dots_length = randomInteger(10,50);
    // Generate dots.
    for (let i = 0; i < dots_length; i++) {
      let dot = {x: randomInteger(0, w), y: randomInteger(0, h)};
      dot.dist = distance(centre, dot);
      dots.push(dot);
    }

    draw()
}

function randomInteger(min, max) {
  return Math.floor(Math.random() * (max - min + 1) ) + min;
}

function distance(p0, p1) {
  return Math.hypot(p0.x - p1.x, p0.y - p1.y);
}

// ================================================================================
gen()