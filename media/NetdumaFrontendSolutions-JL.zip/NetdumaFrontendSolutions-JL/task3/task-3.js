/**
 * Create a better total efficiency calculatation. Design and create better way to display the information than just plain text.
 * Create a better efficiency to colour conversion for each worker. The higher their efficiency, the closer to green their colour should be. The lower, it should be closer to red.
 * Make as many other graphical improvements as you wish.
 */
var panel = $(".panel");

function create_colour(efficiency){
  const neff = Math.round(efficiency * 2.55);  // normalised efficiency (to range [0, 255])
  return `rgb(${255 - neff}, ${neff}, 0)`;
}
function create_worker(worker){
  var newworker = $('<li></li>');
  newworker.text(worker.name);
  newworker.addClass('worker');
  newworker.css('color',create_colour(worker.efficiency));
  return newworker;
}
function create_office_div(office){
  var newdiv = $('<div></div>');
  newdiv.addClass('office');
  newdiv.append($('<label></label>').text(office.company));
  var ol = $('<ul></ul>');
  var sum = 1;
  const numWorkers = office.workers.length;
  for(let i = 0; i < numWorkers; i ++){
    const worker = office.workers[i];
    ol.append(create_worker(worker));
    sum += worker.efficiency;
  }
  const mean_efficiency = sum / numWorkers;
  newdiv.append(ol);
  var active = $('<label></label>');
  active.text(mean_efficiency);
  newdiv.append(active);
  panel.append(newdiv);
  return newdiv;
}
function create_offices(offices){
  for(let i = 0; i < offices.length; i ++){
    create_office_div(offices[i]);
  }
}

function main(){
  offices = d();
  create_offices(offices);
}


$(document).ready(main);
